﻿namespace ScheduleGenerator
{
    partial class EditUserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.ChangeFirstNameButton = new System.Windows.Forms.Button();
            this.ChangeLastNameButton = new System.Windows.Forms.Button();
            this.SetPasswordButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.EditUserBox = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SelectUserButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "See code 1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "See code 2";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(111, 68);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(111, 105);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(111, 139);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 4;
            // 
            // ChangeFirstNameButton
            // 
            this.ChangeFirstNameButton.Location = new System.Drawing.Point(233, 68);
            this.ChangeFirstNameButton.Name = "ChangeFirstNameButton";
            this.ChangeFirstNameButton.Size = new System.Drawing.Size(75, 23);
            this.ChangeFirstNameButton.TabIndex = 5;
            this.ChangeFirstNameButton.Text = "Change";
            this.ChangeFirstNameButton.UseVisualStyleBackColor = true;
            this.ChangeFirstNameButton.Click += new System.EventHandler(this.ChangeFirstNameButton_Click);
            // 
            // ChangeLastNameButton
            // 
            this.ChangeLastNameButton.Location = new System.Drawing.Point(233, 105);
            this.ChangeLastNameButton.Name = "ChangeLastNameButton";
            this.ChangeLastNameButton.Size = new System.Drawing.Size(75, 23);
            this.ChangeLastNameButton.TabIndex = 6;
            this.ChangeLastNameButton.Text = "Change";
            this.ChangeLastNameButton.UseVisualStyleBackColor = true;
            this.ChangeLastNameButton.Click += new System.EventHandler(this.ChangeLastNameButton_Click);
            // 
            // SetPasswordButton
            // 
            this.SetPasswordButton.Location = new System.Drawing.Point(233, 139);
            this.SetPasswordButton.Name = "SetPasswordButton";
            this.SetPasswordButton.Size = new System.Drawing.Size(75, 23);
            this.SetPasswordButton.TabIndex = 7;
            this.SetPasswordButton.Text = "Change";
            this.SetPasswordButton.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "See code 2";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // EditUserBox
            // 
            this.EditUserBox.FormattingEnabled = true;
            this.EditUserBox.Location = new System.Drawing.Point(111, 12);
            this.EditUserBox.Name = "EditUserBox";
            this.EditUserBox.Size = new System.Drawing.Size(100, 24);
            this.EditUserBox.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "Select User";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SelectUserButton
            // 
            this.SelectUserButton.Location = new System.Drawing.Point(233, 12);
            this.SelectUserButton.Name = "SelectUserButton";
            this.SelectUserButton.Size = new System.Drawing.Size(75, 23);
            this.SelectUserButton.TabIndex = 11;
            this.SelectUserButton.Text = "Select";
            this.SelectUserButton.UseVisualStyleBackColor = true;
            // 
            // EditUserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(320, 174);
            this.Controls.Add(this.SelectUserButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.EditUserBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.SetPasswordButton);
            this.Controls.Add(this.ChangeLastNameButton);
            this.Controls.Add(this.ChangeFirstNameButton);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "EditUserForm";
            this.Text = "This will be the admin\'s name";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.EditUserForm_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button ChangeFirstNameButton;
        private System.Windows.Forms.Button ChangeLastNameButton;
        private System.Windows.Forms.Button SetPasswordButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox EditUserBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button SelectUserButton;
    }
}